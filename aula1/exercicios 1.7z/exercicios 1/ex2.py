numero = float(input("Digite o primeiro Número"))
numero2 = float(input("Digite o primeiro Número"))

if(numero > numero2):
    print(numero)
else:
    print(numero2)