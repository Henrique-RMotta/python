numero = float(input("Digite um número"))

if(numero %2 == 0):
    print("é um número par")
else:
    print("é um número impar")
