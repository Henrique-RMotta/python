idadenascimento = float(input("Qual é o seu ano de nascmento ?"))
idade =  2025 - idadenascimento 

if (idade > 18):
    print("Você é maior de idade")
    print(idade)
else:
    print("você é menor de idade")
    print(idade)