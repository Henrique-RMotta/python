numero1 = float(input("Digite o primeiro numero"))
numero2 = float(input("Digite o segundo número"))

if (numero1 == numero2):
    print("Os dois números são iguais")
else:
    print("os dois números são diferentes")