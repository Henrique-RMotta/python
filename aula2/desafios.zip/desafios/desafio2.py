import math

catA = 4
catB = 3
hipotenusa = math.sqrt(catA**2 + catB**2)


print(f"A hipotenusa é:{hipotenusa}")
#autalizado com o import math