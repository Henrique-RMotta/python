Pi = 3.1415
R= float(input("Digite o Raio:"))
h= float(input("Digite a altura:"))
volume = Pi * (R**2) * h
print(f"O volume é {volume:.4f}")
