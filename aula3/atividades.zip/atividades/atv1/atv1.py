num = int(input("Digite um número"))
print(f"seu número ao quadrado é {num**2}")