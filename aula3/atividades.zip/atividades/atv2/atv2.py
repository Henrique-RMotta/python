carac1 = input("Digite o primeiro caracter:")
carac2 = input("Digite o segundo caracter:")
print(f"O usuário digitou {carac1} e {carac2}")