num = int(input("Digite um número:"))
print(f"o usuário digitou o número {num} seu sucessor é: {num + 1}, seu antecessor é: {num - 1} ")