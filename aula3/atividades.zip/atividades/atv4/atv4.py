base = float(input("Digite a base do retângulo:"))
altura = float(input("Digite a altura do retângulo:"))
perimetro = (base*2) + (altura*2)
area = base * altura
print(f"O perimetro do retangulo é: {perimetro} e sua área é: {area}")