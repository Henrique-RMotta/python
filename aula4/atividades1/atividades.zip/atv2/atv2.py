preçocompra = float(input("valor da compra:"))
numprest = int(input("Digite o número de prestações:"))
valorprest = preçocompra/numprest
print(f"o valor das prestações é: {valorprest}")